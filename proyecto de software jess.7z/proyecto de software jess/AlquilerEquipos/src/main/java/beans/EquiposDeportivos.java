/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author andyf
 */
public class EquiposDeportivos {
    
    private int id;
    private String NomEquipo;
    private String TipDeporte;
    private String MarcEquipo;
    private int CantEquipos;
    private boolean Nuevo;

    public EquiposDeportivos(int id, String NomEquipo, String TipDeporte, String MarcEquipo, int CantEquipos, boolean Nuevo) {
        this.id = id;
        this.NomEquipo = NomEquipo;
        this.TipDeporte = TipDeporte;
        this.MarcEquipo = MarcEquipo;
        this.CantEquipos = CantEquipos;
        this.Nuevo = Nuevo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomEquipo() {
        return NomEquipo;
    }

    public void setNomEquipo(String NomEquipo) {
        this.NomEquipo = NomEquipo;
    }

    public String getTipDeporte() {
        return TipDeporte;
    }

    public void setTipDeporte(String TipDeporte) {
        this.TipDeporte = TipDeporte;
    }

    public String getMarcEquipo() {
        return MarcEquipo;
    }

    public void setMarcEquipo(String MarcEquipo) {
        this.MarcEquipo = MarcEquipo;
    }

    public int getCantEquipos() {
        return CantEquipos;
    }

    public void setCantEquipos(int CantEquipos) {
        this.CantEquipos = CantEquipos;
    }

    public boolean isNuevo() {
        return Nuevo;
    }

    public void setNuevo(boolean Nuevo) {
        this.Nuevo = Nuevo;
    }

    @Override
    public String toString() {
        return "EquiposDeportivos{" + "id=" + id + ", NomEquipo=" + NomEquipo + ", TipDeporte=" + TipDeporte + ", MarcEquipo=" + MarcEquipo + ", CantEquipos=" + CantEquipos + ", Nuevo=" + Nuevo + '}';
    }

    
    
    
}
