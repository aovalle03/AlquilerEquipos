-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         11.0.1-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para alquilerequiposd
CREATE DATABASE IF NOT EXISTS `alquilerequiposd` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `alquilerequiposd`;

-- Volcando estructura para tabla alquilerequiposd.alquiler
CREATE TABLE IF NOT EXISTS `alquiler` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`,`username`,`fecha`) USING BTREE,
  KEY `FK_usuarios` (`username`),
  CONSTRAINT `FK_equiposdeportivos` FOREIGN KEY (`id`) REFERENCES `equiposdeportivos` (`id`),
  CONSTRAINT `FK_usuarios` FOREIGN KEY (`username`) REFERENCES `usuarios` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla alquilerequiposd.alquiler: ~0 rows (aproximadamente)

-- Volcando estructura para tabla alquilerequiposd.equiposdeportivos
CREATE TABLE IF NOT EXISTS `equiposdeportivos` (
  `id` int(11) NOT NULL,
  `NomEquipo` varchar(100) DEFAULT NULL,
  `TipDeporte` varchar(100) DEFAULT NULL,
  `MarcEquipo` varchar(100) DEFAULT NULL,
  `CantEquipo` int(11) DEFAULT NULL,
  `Nuevo` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla alquilerequiposd.equiposdeportivos: ~12 rows (aproximadamente)
INSERT INTO `equiposdeportivos` (`id`, `NomEquipo`, `TipDeporte`, `MarcEquipo`, `CantEquipo`, `Nuevo`) VALUES
	(1, 'balon de futbol', 'Futbol', 'Adidas', 5, 0),
	(2, 'balon de futbol', 'Futbol', 'New Balance', 5, 0),
	(3, 'balon de voleibol', 'Voleivol', 'Adidas', 5, 0),
	(4, 'balon de voleibol', 'Voleivol', 'New Balance', 5, 0),
	(5, 'balon de voleibol', 'Voleivol', 'Reebok', 5, 0),
	(6, 'balon de Voleivol', 'Voleivol', 'Asics', 5, 0),
	(7, 'balon de basketball', 'balon de basketball', 'Adidas', 5, 0),
	(8, 'balon de basketball', 'basketball', 'New Balance', 5, 0),
	(9, 'balon de basketball', 'basketball', 'Reebok', 5, 0),
	(10, 'balon de basketball', 'basketball', 'Asics', 5, 0),
	(11, 'bad de beisbol', 'beisbol', 'Adidas', 5, 0),
	(12, 'bad de beisbol', 'beisbol', 'New Balance', 5, 0);

-- Volcando estructura para tabla alquilerequiposd.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `username` varchar(100) NOT NULL,
  `contrasena` varchar(100) DEFAULT NULL,
  `nombres` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `saldo` double(22,2) DEFAULT NULL,
  `premium` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla alquilerequiposd.usuarios: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
